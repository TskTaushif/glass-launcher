package com.glass.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String[] PREFERRED = {
            "com.netflix.ninja", "com.amazon.amazonvideo.livingroom", "in.startv.hotstar.dplus",
            "in.startv.hotstar", "com.google.android.youtube.tv", "com.google.android.youtube",
            "com.sonyliv", "com.apple.atve.androidtv.appletv", "com.google.android.apps.tv.launcherx"
    };
    private static final String EPG = "com.android.providers.tv.permission.READ_EPG_DATA";

    private Prefs prefs;
    private Aurora aurora;
    private ScrollView scroll;
    private LinearLayout col, dockRow, gridBox, shelfRow;
    private HorizontalScrollView shelfScroll;
    private TextView shelfTitle, appsTitle, dockTitle;
    private Pill weatherPill;
    private final List<AppItem> apps = new ArrayList<>();
    private String sig = "";
    private int W, H, margin, gap;
    private boolean appsDirty = true;
    private boolean appsLoading = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Weather.Result lastWeather;
    private long weatherAt = 0;
    private List<News.Item> news;
    private long newsAt = 0;

    private final BroadcastReceiver pkgRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            appsDirty = true;
            ui.removeCallbacks(reloadApps);
            ui.postDelayed(reloadApps, 1000);
        }
    };

    private final Runnable reloadApps = new Runnable() {
        @Override
        public void run() {
            loadApps();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        W = Math.max(dm.widthPixels, dm.heightPixels);
        H = Math.min(dm.widthPixels, dm.heightPixels);
        margin = (int) (W * 0.05f);
        gap = (int) (W * 0.014f);
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        registerReceiver(pkgRx, f);
        buildUi();
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(pkgRx);
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!sig.equals(prefs.signature())) {
            lastWeather = null;
            buildUi();
        }
        if (Build.VERSION.SDK_INT >= 23 && !prefs.b("askedEpg", false)) {
            prefs.putB("askedEpg", true);
            if (checkSelfPermission(EPG) != PackageManager.PERMISSION_GRANTED) {
                try {
                    requestPermissions(new String[]{EPG}, 1);
                } catch (Throwable ignored) {
                }
            }
        }
        if (prefs.b("refresh", false)) {
            prefs.putB("refresh", false);
            appsDirty = true;
            news = null;
            lastWeather = null;
        }
        if (appsDirty) loadApps();
        loadShelf();
        loadWeather();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        scroll.smoothScrollTo(0, 0);
        if (dockRow.getChildCount() > 0) dockRow.getChildAt(0).requestFocus();
    }

    @Override
    public void onBackPressed() {
        scroll.smoothScrollTo(0, 0);
        if (dockRow.getChildCount() > 0) dockRow.getChildAt(0).requestFocus();
    }

    // ---------------------------------------------------------------- UI

    private TextView section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xB3FFFFFF);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.032f);
        t.setPadding(0, (int) (H * 0.035f), 0, (int) (H * 0.015f));
        return t;
    }

    private void buildUi() {
        sig = prefs.signature();
        FrameLayout root = new FrameLayout(this);
        aurora = new Aurora(this);
        aurora.configure(prefs.theme(), prefs.lite());
        root.addView(aurora, new FrameLayout.LayoutParams(-1, -1));

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipChildren(false);
        scroll.setClipToPadding(false);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(margin, (int) (H * 0.04f), margin, (int) (H * 0.12f));
        scroll.addView(col, new FrameLayout.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        // header: clock on the left, weather + settings on the right
        LinearLayout hdr = new LinearLayout(this);
        hdr.setOrientation(LinearLayout.HORIZONTAL);
        hdr.setGravity(android.view.Gravity.CENTER_VERTICAL);
        hdr.setClipChildren(false);
        LinearLayout clock = new LinearLayout(this);
        clock.setOrientation(LinearLayout.VERTICAL);
        TextClock t = new TextClock(this);
        t.setFormat12Hour("h:mm");
        t.setFormat24Hour("HH:mm");
        t.setTextColor(0xFFFFFFFF);
        t.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.085f);
        TextClock d = new TextClock(this);
        d.setFormat12Hour("EEEE, d MMMM");
        d.setFormat24Hour("EEEE, d MMMM");
        d.setTextColor(0xB3FFFFFF);
        d.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.032f);
        clock.addView(t);
        clock.addView(d);
        hdr.addView(clock, new LinearLayout.LayoutParams(0, -2, 1f));

        float pt = H * 0.032f;
        weatherPill = new Pill(this, pt);
        weatherPill.setText("Getting the weather…");
        weatherPill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showForecast();
            }
        });
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-2, -2);
        wl.rightMargin = gap;
        hdr.addView(weatherPill, wl);
        Pill set = new Pill(this, pt);
        set.setText("⚙  " + prefs.name());
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        hdr.addView(set, new LinearLayout.LayoutParams(-2, -2));
        col.addView(hdr, new LinearLayout.LayoutParams(-1, -2));

        // top shelf
        shelfTitle = section("Top Shelf");
        col.addView(shelfTitle);
        shelfScroll = new HorizontalScrollView(this);
        shelfScroll.setHorizontalScrollBarEnabled(false);
        shelfScroll.setClipChildren(false);
        shelfScroll.setClipToPadding(false);
        int vp = (int) (H * 0.025f);
        shelfScroll.setPadding(0, vp, 0, vp);
        shelfRow = new LinearLayout(this);
        shelfRow.setOrientation(LinearLayout.HORIZONTAL);
        shelfRow.setClipChildren(false);
        shelfScroll.addView(shelfRow, new FrameLayout.LayoutParams(-2, -2));
        col.addView(shelfScroll, new LinearLayout.LayoutParams(-1, -2));
        shelfTitle.setVisibility(View.GONE);
        shelfScroll.setVisibility(View.GONE);

        // favourites dock
        dockTitle = section("Favourites");
        col.addView(dockTitle);
        dockRow = new LinearLayout(this);
        dockRow.setOrientation(LinearLayout.HORIZONTAL);
        dockRow.setClipChildren(false);
        dockRow.setPadding(0, vp, 0, vp);
        col.addView(dockRow, new LinearLayout.LayoutParams(-1, -2));

        // all apps
        appsTitle = section("All Apps");
        col.addView(appsTitle);
        gridBox = new LinearLayout(this);
        gridBox.setOrientation(LinearLayout.VERTICAL);
        gridBox.setClipChildren(false);
        gridBox.setPadding(0, vp, 0, 0);
        col.addView(gridBox, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        populateDock();
        populateGrid();
        updateWeatherText();
    }

    private Tile makeTile(final AppItem item, int w, int h) {
        Tile t = new Tile(this, item, w, h, prefs.style(), prefs.theme(), prefs.lite());
        t.cb = new Tile.FocusCb() {
            @Override
            public void on(Tile tile) {
                aurora.setAccent(tile.item.color);
            }
        };
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(item);
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showOptions(item);
                return true;
            }
        });
        t.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int k, KeyEvent e) {
                if (k == KeyEvent.KEYCODE_MENU && e.getAction() == KeyEvent.ACTION_UP) {
                    showOptions(item);
                    return true;
                }
                return false;
            }
        });
        return t;
    }

    private List<AppItem> favItems() {
        List<String> favs = prefs.favs();
        if (favs.isEmpty() && !apps.isEmpty()) {
            for (String p : PREFERRED) {
                if (favs.size() >= 6) break;
                if (find(p) != null && !favs.contains(p)) favs.add(p);
            }
            for (AppItem a : apps) {
                if (favs.size() >= 6) break;
                if (!favs.contains(a.pkg)) favs.add(a.pkg);
            }
            prefs.setFavs(favs);
        }
        List<AppItem> out = new ArrayList<>();
        for (String p : favs) {
            AppItem a = find(p);
            if (a != null) out.add(a);
        }
        return out;
    }

    private AppItem find(String pkg) {
        for (AppItem a : apps) {
            if (a.pkg.equals(pkg)) return a;
        }
        return null;
    }

    private void populateDock() {
        dockRow.removeAllViews();
        List<AppItem> favs = favItems();
        int n = prefs.dock();
        int tw = (W - 2 * margin - (n - 1) * gap) / n;
        int th = tw * 9 / 16;
        for (int i = 0; i < n && i < favs.size(); i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tw, -2);
            lp.rightMargin = gap;
            dockRow.addView(makeTile(favs.get(i), tw, th), lp);
        }
        dockTitle.setVisibility(dockRow.getChildCount() == 0 ? View.GONE : View.VISIBLE);
        if (getCurrentFocus() == null && dockRow.getChildCount() > 0) dockRow.getChildAt(0).requestFocus();
    }

    private void populateGrid() {
        gridBox.removeAllViews();
        int cols = 6;
        int tw = (W - 2 * margin - (cols - 1) * gap) / cols;
        int th = tw * 9 / 16;
        appsTitle.setText("All Apps" + (apps.isEmpty() ? "" : "  (" + apps.size() + ")"));
        LinearLayout row = null;
        for (int i = 0; i < apps.size(); i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setClipChildren(false);
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
                rl.bottomMargin = (int) (gap * 0.6f);
                gridBox.addView(row, rl);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tw, -2);
            lp.rightMargin = gap;
            row.addView(makeTile(apps.get(i), tw, th), lp);
        }
    }

    // ---------------------------------------------------------------- data

    private void loadApps() {
        if (appsLoading) return;
        appsLoading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<AppItem> l = AppItem.load(MainActivity.this);
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        apps.clear();
                        apps.addAll(l);
                        appsDirty = false;
                        appsLoading = false;
                        populateDock();
                        populateGrid();
                    }
                });
            }
        }).start();
    }

    private void loadWeather() {
        if (!prefs.weather()) {
            weatherPill.setVisibility(View.GONE);
            return;
        }
        weatherPill.setVisibility(View.VISIBLE);
        if (lastWeather != null && SystemClock.uptimeMillis() - weatherAt < 20 * 60 * 1000L) {
            updateWeatherText();
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final Weather.Result r = Weather.fetch(prefs);
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            lastWeather = r;
                            weatherAt = SystemClock.uptimeMillis();
                            updateWeatherText();
                        }
                    });
                } catch (Throwable e) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (lastWeather == null) weatherPill.setText("Weather unavailable");
                        }
                    });
                }
            }
        }).start();
    }

    private void updateWeatherText() {
        if (weatherPill == null || lastWeather == null) return;
        weatherPill.setText(Weather.icon(lastWeather.code) + "  " + Math.round(lastWeather.temp) + "°  ·  "
                + prefs.city());
    }

    private void showForecast() {
        if (lastWeather == null) {
            Toast.makeText(this, "Weather not loaded yet", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(Weather.icon(lastWeather.code)).append("  Now: ").append(Math.round(lastWeather.temp))
                .append("°  ").append(Weather.desc(lastWeather.code)).append("\n\n");
        SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat out = new SimpleDateFormat("EEE d MMM", Locale.getDefault());
        for (Weather.Day dy : lastWeather.days) {
            String label = dy.date;
            try {
                Date dt = in.parse(dy.date);
                if (dt != null) label = out.format(dt);
            } catch (Throwable ignored) {
            }
            sb.append(label).append("   ").append(Weather.icon(dy.code)).append("  ")
                    .append(Math.round(dy.min)).append("° – ").append(Math.round(dy.max)).append("°   ")
                    .append(Weather.desc(dy.code)).append("\n");
        }
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("5-day forecast – " + prefs.city())
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    private void loadShelf() {
        final int mode = prefs.shelf();
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<WatchNext.Entry> wn = new ArrayList<>();
                if (mode != 2) wn = WatchNext.query(MainActivity.this);
                List<News.Item> nw = null;
                if (mode != 1) {
                    if (news != null && SystemClock.uptimeMillis() - newsAt < 15 * 60 * 1000L) {
                        nw = news;
                    } else {
                        try {
                            nw = News.fetch();
                        } catch (Throwable ignored) {
                        }
                    }
                }
                final List<WatchNext.Entry> fw = wn;
                final List<News.Item> fn = nw;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (fn != null && !fn.isEmpty()) {
                            news = fn;
                            newsAt = SystemClock.uptimeMillis();
                        }
                        populateShelf(fw, fn);
                    }
                });
            }
        }).start();
    }

    private void populateShelf(List<WatchNext.Entry> wn, List<News.Item> nw) {
        shelfRow.removeAllViews();
        boolean lite = prefs.lite();
        int cw = (int) (W * 0.27f);
        int ch = cw * 9 / 16;
        ShelfCard.FocusCb fcb = new ShelfCard.FocusCb() {
            @Override
            public void on(int color) {
                aurora.setAccent(color);
            }
        };
        int count = 0;
        for (final WatchNext.Entry e : wn) {
            String sub = "Continue watching";
            AppItem a = e.pkg == null ? null : find(e.pkg);
            if (a != null) sub = "Continue watching · " + a.label;
            ShelfCard c = new ShelfCard(this, cw, ch, e.title, sub, a != null ? a.color : 0xFF2B3A67, lite);
            c.cb = fcb;
            c.setPoster(e.poster);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent i = Intent.parseUri(e.intentUri, Intent.URI_INTENT_SCHEME);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Throwable t) {
                        Toast.makeText(MainActivity.this, "Can't open this title", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
            lp.rightMargin = gap;
            shelfRow.addView(c, lp);
            count++;
        }
        if (nw != null) {
            int[] tints = {0xFF3A4F8F, 0xFF7A3F8F, 0xFF2F7A6E, 0xFF8F5A2F};
            int k = 0;
            for (final News.Item n : nw) {
                ShelfCard c = new ShelfCard(this, cw, ch, n.title, n.source, tints[k++ % tints.length], lite);
                c.cb = fcb;
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openNews(n);
                    }
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
                lp.rightMargin = gap;
                shelfRow.addView(c, lp);
                count++;
            }
        }
        int vis = count == 0 ? View.GONE : View.VISIBLE;
        shelfTitle.setVisibility(vis);
        shelfScroll.setVisibility(vis);
        if (getCurrentFocus() == null && dockRow.getChildCount() > 0) dockRow.getChildAt(0).requestFocus();
    }

    private void openNews(final News.Item n) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(n.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable t) {
            new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle(n.source)
                    .setMessage(n.title + "\n\n(No browser found on this TV to open the full story.)")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    // ---------------------------------------------------------------- actions

    private void launch(AppItem item) {
        try {
            startActivity(item.launchIntent());
        } catch (Throwable t) {
            Toast.makeText(this, "Can't open " + item.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void showOptions(final AppItem item) {
        final List<String> favs = prefs.favs();
        final boolean isFav = favs.contains(item.pkg);
        final List<String> opts = new ArrayList<>();
        opts.add("Open");
        opts.add(isFav ? "Remove from Favourites" : "Add to Favourites");
        if (isFav) opts.add("Move to front");
        opts.add("App info");
        opts.add("Uninstall");
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(item.label)
                .setItems(opts.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int which) {
                        String s = opts.get(which);
                        if (s.equals("Open")) {
                            launch(item);
                        } else if (s.equals("Add to Favourites")) {
                            favs.add(item.pkg);
                            prefs.setFavs(favs);
                            populateDock();
                        } else if (s.equals("Remove from Favourites")) {
                            favs.remove(item.pkg);
                            prefs.setFavs(favs);
                            populateDock();
                        } else if (s.equals("Move to front")) {
                            favs.remove(item.pkg);
                            favs.add(0, item.pkg);
                            prefs.setFavs(favs);
                            populateDock();
                        } else if (s.equals("App info")) {
                            try {
                                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.parse("package:" + item.pkg)));
                            } catch (Throwable t) {
                                Toast.makeText(MainActivity.this, "App info not available", Toast.LENGTH_SHORT).show();
                            }
                        } else if (s.equals("Uninstall")) {
                            try {
                                startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + item.pkg)));
                            } catch (Throwable t) {
                                Toast.makeText(MainActivity.this, "Can't uninstall this app", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                })
                .show();
    }
}
