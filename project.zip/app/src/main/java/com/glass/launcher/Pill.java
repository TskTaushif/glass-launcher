package com.glass.launcher;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

/** Rounded glass button/label that turns white when focused (like tvOS). */
public class Pill extends TextView {
    private final GradientDrawable bg = new GradientDrawable();

    public Pill(Context c, float textPx) {
        super(c);
        setTextSize(TypedValue.COMPLEX_UNIT_PX, textPx);
        setGravity(Gravity.CENTER_VERTICAL);
        int ph = (int) (textPx * 1.0f);
        int pv = (int) (textPx * 0.5f);
        setPadding(ph, pv, ph, pv);
        bg.setCornerRadius(textPx * 2.5f);
        setBackground(bg);
        setFocusable(true);
        setClickable(true);
        setSingleLine(true);
        paint(false);
    }

    private void paint(boolean focused) {
        bg.setColor(focused ? 0xFFFFFFFF : 0x33FFFFFF);
        setTextColor(focused ? 0xFF111111 : 0xFFFFFFFF);
    }

    @Override
    protected void onFocusChanged(boolean gain, int direction, Rect prev) {
        super.onFocusChanged(gain, direction, prev);
        paint(gain);
        float s = gain ? 1.06f : 1f;
        animate().scaleX(s).scaleY(s).setDuration(120).start();
    }
}
