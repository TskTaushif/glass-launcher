package com.glass.launcher;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Optional "Home button catcher". When the TV's stock launcher comes to the front
 * (because Home was pressed), this brings Glass Launcher back. It only looks at the
 * package name of the window that opened. It does not read any screen content.
 */
public class RemapService extends AccessibilityService {
    private long lastLaunch = 0;
    private long homesAt = 0;
    private final Set<String> homes = new HashSet<>();

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence cs = e.getPackageName();
        if (cs == null) return;
        if (!new Prefs(this).catchHome()) return;
        refreshHomes();
        if (!homes.contains(cs.toString())) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastLaunch < 1500) return;
        lastLaunch = now;
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    private void refreshHomes() {
        long now = SystemClock.uptimeMillis();
        if (!homes.isEmpty() && now - homesAt < 60000) return;
        homesAt = now;
        homes.clear();
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        List<ResolveInfo> l = getPackageManager().queryIntentActivities(h, 0);
        for (ResolveInfo ri : l) {
            if (ri.activityInfo != null && !ri.activityInfo.packageName.equals(getPackageName())) {
                homes.add(ri.activityInfo.packageName);
            }
        }
    }

    @Override
    public void onInterrupt() {
    }
}
