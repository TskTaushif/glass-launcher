package com.glass.launcher;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class News {
    public static class Item {
        public String title;
        public String link;
        public String source;
    }

    private static final String[][] FEEDS = {
            {"Times of India", "https://timesofindia.indiatimes.com/rssfeeds/-2128936835.cms"},
            {"Hindustan Times", "https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml"},
            {"NDTV", "https://feeds.feedburner.com/ndtvnews-india-news"},
            {"The Hindu", "https://www.thehindu.com/news/international/feeder/default.rss"}
    };

    public static List<Item> fetch() {
        List<List<Item>> perFeed = new ArrayList<>();
        for (String[] f : FEEDS) {
            try {
                perFeed.add(parse(f[0], Util.httpGet(f[1]), 4));
            } catch (Throwable ignored) {
            }
        }
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            for (List<Item> l : perFeed) {
                if (i < l.size()) out.add(l.get(i));
            }
        }
        return out;
    }

    static List<Item> parse(String source, String xml, int max) throws Exception {
        List<Item> out = new ArrayList<>();
        XmlPullParser p = Xml.newPullParser();
        p.setInput(new StringReader(xml));
        boolean in = false;
        String title = null;
        String link = null;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT && out.size() < max) {
            if (ev == XmlPullParser.START_TAG) {
                String n = p.getName();
                if ("item".equals(n)) {
                    in = true;
                    title = null;
                    link = null;
                } else if (in && "title".equals(n)) {
                    title = p.nextText();
                } else if (in && "link".equals(n)) {
                    link = p.nextText();
                }
            } else if (ev == XmlPullParser.END_TAG && "item".equals(p.getName())) {
                in = false;
                if (title != null && title.trim().length() > 0) {
                    Item it = new Item();
                    it.title = title.trim();
                    it.link = link == null ? "" : link.trim();
                    it.source = source;
                    out.add(it);
                }
            }
            ev = p.next();
        }
        return out;
    }
}
