package com.glass.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        try {
            if (!new Prefs(c).autostart()) return;
            Intent s = new Intent(c, MainActivity.class);
            s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(s);
        } catch (Throwable ignored) {
        }
    }
}
