package com.glass.launcher;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Big card for the Top Shelf (Continue Watching / news headline). */
public class ShelfCard extends FrameLayout {
    public interface FocusCb {
        void on(int color);
    }

    public FocusCb cb;
    private final ImageView poster;
    private final View ring;
    private final boolean lite;
    private final int tint;
    private final float lift;

    public ShelfCard(Context c, int w, int h, String title, String sub, int tint, boolean lite) {
        super(c);
        this.lite = lite;
        this.tint = tint;
        this.lift = Util.dp(c, 12);
        setFocusable(true);
        setClickable(true);
        float radius = h * 0.08f;

        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Util.shade(tint, 0.9f, 1.1f), Util.shade(tint, 1f, 0.5f)});
        bg.setCornerRadius(radius);
        setBackground(bg);
        setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        setClipToOutline(true);

        poster = new ImageView(c);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        addView(poster, new FrameLayout.LayoutParams(w, h));

        View scrim = new View(c);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00000000, 0xDD000000}));
        addView(scrim, new FrameLayout.LayoutParams(w, (int) (h * 0.7f), Gravity.BOTTOM));

        LinearLayout txt = new LinearLayout(c);
        txt.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (h * 0.06f);
        txt.setPadding(pad, pad, pad, pad);
        TextView t = new TextView(c);
        t.setText(title);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, h * 0.085f);
        t.setMaxLines(3);
        t.setEllipsize(TextUtils.TruncateAt.END);
        txt.addView(t);
        TextView s = new TextView(c);
        s.setText(sub);
        s.setTextColor(0xCCFFFFFF);
        s.setTextSize(TypedValue.COMPLEX_UNIT_PX, h * 0.065f);
        s.setSingleLine(true);
        txt.addView(s);
        addView(txt, new FrameLayout.LayoutParams(w, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        ring = new View(c);
        GradientDrawable rg = new GradientDrawable();
        rg.setCornerRadius(radius);
        rg.setStroke(Math.max(2, Util.dp(c, 3)), 0xFFFFFFFF);
        ring.setBackground(rg);
        ring.setAlpha(0f);
        addView(ring, new FrameLayout.LayoutParams(w, h));
    }

    public void setPoster(String uri) {
        Util.loadInto(getContext(), uri, poster, 640);
    }

    @Override
    protected void onFocusChanged(boolean gain, int direction, Rect prev) {
        super.onFocusChanged(gain, direction, prev);
        float s = gain ? 1.07f : 1f;
        long d = lite ? 0 : 160;
        animate().scaleX(s).scaleY(s).translationZ(gain && !lite ? lift : 0f).setDuration(d).start();
        ring.animate().alpha(gain ? 1f : 0f).setDuration(d).start();
        if (gain && cb != null) cb.on(tint);
    }
}
