package com.glass.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Util {
    private static final LruCache<String, Bitmap> CACHE = new LruCache<>(48);

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    public static byte[] httpBytes(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android TV) GlassLauncher");
        try {
            InputStream in = c.getInputStream();
            try {
                return readAll(in);
            } finally {
                in.close();
            }
        } finally {
            c.disconnect();
        }
    }

    public static String httpGet(String u) throws IOException {
        return new String(httpBytes(u), "UTF-8");
    }

    public static Bitmap decode(byte[] d, int reqW) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(d, 0, d.length, o);
        int s = 1;
        while (o.outWidth / (s * 2) >= reqW) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        return BitmapFactory.decodeByteArray(d, 0, d.length, o2);
    }

    /** Loads http(s) or content:// images in the background into the ImageView. */
    public static void loadInto(final Context c, final String uri, final ImageView iv, final int reqW) {
        if (uri == null || uri.length() == 0) return;
        iv.setTag(uri);
        Bitmap hit = CACHE.get(uri);
        if (hit != null) {
            iv.setImageBitmap(hit);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    byte[] data;
                    if (uri.startsWith("http")) {
                        data = httpBytes(uri);
                    } else {
                        InputStream in = c.getContentResolver().openInputStream(Uri.parse(uri));
                        if (in == null) return;
                        data = readAll(in);
                        in.close();
                    }
                    final Bitmap bm = decode(data, reqW);
                    if (bm == null) return;
                    CACHE.put(uri, bm);
                    iv.post(new Runnable() {
                        @Override
                        public void run() {
                            if (uri.equals(iv.getTag())) iv.setImageBitmap(bm);
                        }
                    });
                } catch (Throwable ignored) {
                }
            }
        }).start();
    }

    public static int shade(int c, float sMul, float vMul) {
        float[] h = new float[3];
        Color.colorToHSV(c, h);
        h[1] = Math.min(1f, h[1] * sMul);
        h[2] = Math.min(1f, h[2] * vMul);
        return Color.HSVToColor(h);
    }

    public static final int DEFAULT_COLOR = 0xFF3B4366;

    /** Rough "brand colour" of an icon. */
    public static int dominant(Drawable d) {
        try {
            Bitmap b = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            d.setBounds(0, 0, 24, 24);
            d.draw(cv);
            float r = 0, g = 0, bl = 0, ws = 0;
            float[] hsv = new float[3];
            for (int x = 0; x < 24; x++) {
                for (int y = 0; y < 24; y++) {
                    int p = b.getPixel(x, y);
                    if (Color.alpha(p) < 128) continue;
                    Color.colorToHSV(p, hsv);
                    float w = hsv[1] * hsv[2] + 0.02f;
                    r += Color.red(p) * w;
                    g += Color.green(p) * w;
                    bl += Color.blue(p) * w;
                    ws += w;
                }
            }
            b.recycle();
            if (ws <= 0) return DEFAULT_COLOR;
            int c = Color.rgb((int) (r / ws), (int) (g / ws), (int) (bl / ws));
            float[] h = new float[3];
            Color.colorToHSV(c, h);
            if (h[1] < 0.15f) return DEFAULT_COLOR;
            h[1] = Math.max(h[1], 0.45f);
            h[2] = Math.min(Math.max(h[2], 0.45f), 0.85f);
            return Color.HSVToColor(h);
        } catch (Throwable t) {
            return DEFAULT_COLOR;
        }
    }
}
