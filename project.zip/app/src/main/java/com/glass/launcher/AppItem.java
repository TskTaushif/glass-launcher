package com.glass.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;

public class AppItem {
    public String label;
    public String pkg;
    public ComponentName cn;
    public Drawable icon;
    public Drawable banner;
    public int color = Util.DEFAULT_COLOR;

    public Intent launchIntent() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.setComponent(cn);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        return i;
    }

    /** Every app that has a TV launcher entry, plus normal launcher entries. */
    public static List<AppItem> load(Context c) {
        PackageManager pm = c.getPackageManager();
        LinkedHashMap<String, AppItem> map = new LinkedHashMap<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
            for (ResolveInfo ri : list) {
                ActivityInfo ai = ri.activityInfo;
                if (ai == null) continue;
                if (ai.packageName.equals(c.getPackageName())) continue;
                if (map.containsKey(ai.packageName)) continue;
                try {
                    AppItem it = new AppItem();
                    it.pkg = ai.packageName;
                    it.cn = new ComponentName(ai.packageName, ai.name);
                    CharSequence lab = ri.loadLabel(pm);
                    it.label = lab == null ? ai.packageName : lab.toString();
                    it.icon = ri.loadIcon(pm);
                    Drawable b = ai.loadBanner(pm);
                    if (b == null && ai.applicationInfo != null) b = ai.applicationInfo.loadBanner(pm);
                    it.banner = b;
                    if (it.icon != null) it.color = Util.dominant(it.icon);
                    map.put(it.pkg, it);
                } catch (Throwable ignored) {
                }
            }
        }
        List<AppItem> out = new ArrayList<>(map.values());
        Collections.sort(out, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem a, AppItem b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        return out;
    }
}
