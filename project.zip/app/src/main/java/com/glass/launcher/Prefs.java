package com.glass.launcher;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

public class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getSharedPreferences("glass", Context.MODE_PRIVATE);
    }

    public int i(String k, int d) { return sp.getInt(k, d); }
    public boolean b(String k, boolean d) { return sp.getBoolean(k, d); }
    public String s(String k, String d) { return sp.getString(k, d); }
    public void putI(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public void putB(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public void putS(String k, String v) { sp.edit().putString(k, v).apply(); }

    // dock size 4..6
    public int dock() { return i("dock", 6); }
    // 0 = tvOS brand-colour tiles, 1 = original banners
    public int style() { return i("style", 0); }
    // 0 = frosted glass, 1 = dark
    public int theme() { return i("theme", 0); }
    public boolean lite() { return b("lite", false); }
    // 0 = continue watching + news, 1 = continue watching only, 2 = news only
    public int shelf() { return i("shelf", 0); }
    public boolean weather() { return b("weather", true); }
    public boolean fahrenheit() { return b("fahr", false); }
    public boolean autostart() { return b("autostart", true); }
    public boolean catchHome() { return b("catchhome", true); }
    public String name() { return s("name", "Guest"); }
    public String city() { return s("city", "Nagpur"); }
    public String lat() { return s("lat", "21.1458"); }
    public String lon() { return s("lon", "79.0882"); }

    public void setCity(String city, String lat, String lon) {
        sp.edit().putString("city", city).putString("lat", lat).putString("lon", lon).apply();
    }

    public List<String> favs() {
        List<String> out = new ArrayList<>();
        String v = s("favs", "");
        if (v.length() > 0) {
            for (String p : v.split(",")) {
                if (p.length() > 0) out.add(p);
            }
        }
        return out;
    }

    public void setFavs(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String p : l) {
            if (sb.length() > 0) sb.append(',');
            sb.append(p);
        }
        putS("favs", sb.toString());
    }

    /** Anything that needs the whole UI to be rebuilt when it changes. */
    public String signature() {
        return dock() + "|" + style() + "|" + theme() + "|" + lite() + "|" + shelf() + "|" + weather()
                + "|" + fahrenheit() + "|" + city() + "|" + name();
    }
}
