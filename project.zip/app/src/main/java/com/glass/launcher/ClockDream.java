package com.glass.launcher;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.service.dreams.DreamService;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextClock;

import java.util.Random;

/** Screensaver: a big clock that slowly drifts around so the screen does not burn in. */
public class ClockDream extends DreamService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private LinearLayout box;
    private Runnable drift;

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        TextClock t = new TextClock(this);
        t.setFormat12Hour("h:mm");
        t.setFormat24Hour("HH:mm");
        t.setTextColor(0xFFFFFFFF);
        t.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.min(dm.widthPixels, dm.heightPixels) * 0.3f);
        TextClock d = new TextClock(this);
        d.setFormat12Hour("EEEE, d MMMM");
        d.setFormat24Hour("EEEE, d MMMM");
        d.setTextColor(0xAAFFFFFF);
        d.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.min(dm.widthPixels, dm.heightPixels) * 0.06f);
        box.addView(t);
        box.addView(d);
        root.addView(box, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setContentView(root);
        drift = new Runnable() {
            @Override
            public void run() {
                float dx = (rnd.nextFloat() - 0.5f) * dm.widthPixels * 0.2f;
                float dy = (rnd.nextFloat() - 0.5f) * dm.heightPixels * 0.2f;
                box.animate().translationX(dx).translationY(dy).setDuration(3000).start();
                h.postDelayed(this, 30000);
            }
        };
    }

    @Override
    public void onDreamingStarted() {
        super.onDreamingStarted();
        h.post(drift);
    }

    @Override
    public void onDreamingStopped() {
        h.removeCallbacks(drift);
        super.onDreamingStopped();
    }
}
