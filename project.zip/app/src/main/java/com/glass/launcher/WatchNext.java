package com.glass.launcher;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Reads the Android TV "Watch Next" row that streaming apps fill in (Netflix, YouTube, ...). */
public class WatchNext {
    public static class Entry {
        public String title;
        public String poster;
        public String intentUri;
        public String pkg;
    }

    public static List<Entry> query(Context c) {
        List<Entry> out = new ArrayList<>();
        Cursor cur = null;
        try {
            Uri uri = Uri.parse("content://android.media.tv/watch_next_program");
            String[] proj = {"title", "poster_art_uri", "thumbnail_uri", "intent_uri", "package_name"};
            cur = c.getContentResolver().query(uri, proj, null, null, "last_engagement_time_utc_millis DESC");
            if (cur == null) return out;
            Set<String> seen = new HashSet<>();
            while (cur.moveToNext() && out.size() < 12) {
                Entry e = new Entry();
                e.title = cur.getString(0);
                String poster = cur.getString(1);
                if (poster == null || poster.length() == 0) poster = cur.getString(2);
                e.poster = poster;
                e.intentUri = cur.getString(3);
                e.pkg = cur.getString(4);
                if (e.title == null || e.intentUri == null) continue;
                if (!seen.add(e.title)) continue;
                out.add(e);
            }
        } catch (Throwable ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return out;
    }
}
