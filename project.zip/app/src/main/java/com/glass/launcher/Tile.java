package com.glass.launcher;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** One app tile: rounded glass card, icon or banner, shine, focus ring and a label below. */
public class Tile extends LinearLayout {
    public interface FocusCb {
        void on(Tile t);
    }

    public final AppItem item;
    public FocusCb cb;
    private final FrameLayout card;
    private final View ring;
    private final TextView label;
    private final boolean lite;
    private final float lift;

    public Tile(Context c, AppItem it, int w, int h, int style, int theme, boolean lite) {
        super(c);
        this.item = it;
        this.lite = lite;
        this.lift = Util.dp(c, 12);
        setOrientation(VERTICAL);
        setFocusable(true);
        setClickable(true);
        setClipChildren(false);
        setClipToPadding(false);

        float radius = h * 0.14f;
        card = new FrameLayout(c);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(radius);
        boolean useBanner = style == 1 && it.banner != null;
        if (style == 0) {
            bg.setOrientation(GradientDrawable.Orientation.TL_BR);
            bg.setColors(new int[]{Util.shade(it.color, 0.9f, 1.15f), Util.shade(it.color, 1.0f, 0.65f)});
        } else {
            bg.setColor(theme == 1 ? 0xCC1C1C1E : 0x40FFFFFF);
        }
        card.setBackground(bg);
        card.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        card.setClipToOutline(true);

        ImageView img = new ImageView(c);
        if (useBanner) {
            img.setImageDrawable(it.banner);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(img, new FrameLayout.LayoutParams(w, h));
        } else {
            int s = (int) (h * 0.56f);
            img.setImageDrawable(it.icon);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            card.addView(img, new FrameLayout.LayoutParams(s, s, Gravity.CENTER));
        }

        View shine = new View(c);
        GradientDrawable sh = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x45FFFFFF, 0x00FFFFFF});
        shine.setBackground(sh);
        card.addView(shine, new FrameLayout.LayoutParams(w, h / 2, Gravity.TOP));

        ring = new View(c);
        GradientDrawable rg = new GradientDrawable();
        rg.setCornerRadius(radius);
        rg.setStroke(Math.max(2, Util.dp(c, 3)), 0xFFFFFFFF);
        ring.setBackground(rg);
        ring.setAlpha(0f);
        card.addView(ring, new FrameLayout.LayoutParams(w, h));

        addView(card, new LinearLayout.LayoutParams(w, h));

        label = new TextView(c);
        label.setText(it.label);
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, h * 0.14f);
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        label.setGravity(Gravity.CENTER);
        label.setAlpha(0f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (h * 0.10f);
        addView(label, lp);
    }

    @Override
    protected void onFocusChanged(boolean gain, int direction, Rect prev) {
        super.onFocusChanged(gain, direction, prev);
        float s = gain ? 1.12f : 1f;
        long d = lite ? 0 : 160;
        card.animate().scaleX(s).scaleY(s).translationZ(gain && !lite ? lift : 0f).setDuration(d).start();
        ring.animate().alpha(gain ? 1f : 0f).setDuration(d).start();
        label.animate().alpha(gain ? 1f : 0f).setDuration(d).start();
        if (gain && cb != null) cb.on(this);
    }
}
