package com.glass.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private Prefs prefs;
    private LinearLayout box;
    private int H;
    private int W;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        W = Math.max(dm.widthPixels, dm.heightPixels);
        H = Math.min(dm.widthPixels, dm.heightPixels);

        FrameLayout root = new FrameLayout(this);
        Aurora bg = new Aurora(this);
        bg.configure(prefs.theme(), true);
        bg.setAccent(0xFF4A3F9F);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding((int) (W * 0.2f), (int) (H * 0.05f), (int) (W * 0.2f), (int) (H * 0.08f));
        TextView title = new TextView(this);
        title.setText("Settings");
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.06f);
        title.setPadding(0, 0, 0, (int) (H * 0.03f));
        outer.addView(title);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        outer.addView(box, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(outer, new FrameLayout.LayoutParams(-1, -2));
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (box != null) render();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private String onOff(boolean v) {
        return v ? "On" : "Off";
    }

    private boolean a11yOn() {
        try {
            String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (s == null) return false;
            String me = new ComponentName(this, RemapService.class).flattenToString();
            String me2 = new ComponentName(this, RemapService.class).flattenToShortString();
            return s.contains(me) || s.contains(me2);
        } catch (Throwable t) {
            return false;
        }
    }

    private void add(String text, View.OnClickListener l) {
        Pill p = new Pill(this, H * 0.034f);
        p.setText(text);
        p.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = (int) (H * 0.016f);
        box.addView(p, lp);
    }

    private void render() {
        int idx = -1;
        View f = getCurrentFocus();
        if (f != null) idx = box.indexOfChild(f);
        box.removeAllViews();

        add("Favourites dock size:  " + prefs.dock() + " apps", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int d = prefs.dock();
                prefs.putI("dock", d >= 6 ? 4 : d + 1);
                render();
            }
        });
        add("App icon style:  " + (prefs.style() == 0 ? "tvOS (brand colours + glass shine)" : "Original banners"),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        prefs.putI("style", prefs.style() == 0 ? 1 : 0);
                        render();
                    }
                });
        add("Appearance:  " + (prefs.theme() == 0 ? "Frosted glass" : "Dark"), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putI("theme", prefs.theme() == 0 ? 1 : 0);
                render();
            }
        });
        add("Lite mode (fewer animations, for slow TVs):  " + onOff(prefs.lite()), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putB("lite", !prefs.lite());
                render();
            }
        });
        String[] shelfNames = {"Continue Watching + News", "Continue Watching only", "News only"};
        add("Top Shelf:  " + shelfNames[prefs.shelf()], new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putI("shelf", (prefs.shelf() + 1) % 3);
                render();
            }
        });
        add("Weather on home screen:  " + onOff(prefs.weather()), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putB("weather", !prefs.weather());
                render();
            }
        });
        add("Temperature unit:  " + (prefs.fahrenheit() ? "°F" : "°C"), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putB("fahr", !prefs.fahrenheit());
                render();
            }
        });
        add("City:  " + prefs.city() + "   (change)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askCity();
            }
        });
        add("Auto-detect city from internet (sends your IP to ipwho.is)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                autoCity();
            }
        });
        add("Your name:  " + prefs.name() + "   (change)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askName();
            }
        });
        add("Start automatically when TV turns on:  " + onOff(prefs.autostart()), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putB("autostart", !prefs.autostart());
                render();
            }
        });
        add("Make this the Home screen (choose Glass Launcher)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                } catch (Throwable t) {
                    toast("Press the Home button and choose Glass Launcher → Always");
                }
            }
        });
        add("Home-button catcher (Accessibility):  " + onOff(a11yOn()) + "   (open)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } catch (Throwable t) {
                    toast("Accessibility settings not found on this TV");
                }
            }
        });
        add("Home-button catcher use:  " + onOff(prefs.catchHome()), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putB("catchhome", !prefs.catchHome());
                render();
            }
        });
        add("Refresh app list", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.putB("refresh", true);
                toast("App list, news and weather will refresh when you go back");
            }
        });
        add("Glass Launcher 1.0", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("Made for Intex LED-SHF3265 (Android 9)");
            }
        });

        if (idx < 0) idx = 0;
        if (idx >= box.getChildCount()) idx = box.getChildCount() - 1;
        box.getChildAt(idx).requestFocus();
    }

    private void askCity() {
        final EditText et = new EditText(this);
        et.setHint("City name");
        et.setSingleLine(true);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Search city")
                .setView(et)
                .setPositiveButton("Search", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        searchCity(et.getText().toString().trim());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void searchCity(final String q) {
        if (q.length() == 0) return;
        toast("Searching…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String[] r = Weather.geocode(q);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            prefs.setCity(r[0], r[1], r[2]);
                            toast("City set: " + r[0]);
                            render();
                        }
                    });
                } catch (Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toast("City not found, or no internet");
                        }
                    });
                }
            }
        }).start();
    }

    private void autoCity() {
        toast("Detecting…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String[] r = Weather.ipLocate();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            prefs.setCity(r[0], r[1], r[2]);
                            toast("City set: " + r[0]);
                            render();
                        }
                    });
                } catch (Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toast("Could not detect location");
                        }
                    });
                }
            }
        }).start();
    }

    private void askName() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(prefs.name());
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Your name")
                .setView(et)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = et.getText().toString().trim();
                        if (n.length() > 0) prefs.putS("name", n);
                        render();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
