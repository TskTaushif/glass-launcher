package com.glass.launcher;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Soft coloured background that gently changes colour with the focused app. */
public class Aurora extends View {
    private final Paint paint = new Paint();
    private final ArgbEvaluator eval = new ArgbEvaluator();
    private int shown = 0xFF3B4366;
    private int target = 0xFF3B4366;
    private int theme = 0;
    private boolean lite = false;
    private ValueAnimator anim;

    public Aurora(Context c) {
        super(c);
    }

    public void configure(int theme, boolean lite) {
        this.theme = theme;
        this.lite = lite;
        invalidate();
    }

    public void setAccent(int color) {
        if (color == target) return;
        target = color;
        if (anim != null) anim.cancel();
        if (lite) {
            shown = color;
            invalidate();
            return;
        }
        final int from = shown;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(550);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                float f = (Float) a.getAnimatedValue();
                shown = (Integer) eval.evaluate(f, from, target);
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;
        int top = theme == 1 ? 0xFF060608 : 0xFF0E1230;
        int bot = theme == 1 ? 0xFF000000 : 0xFF1A0F2E;
        paint.setShader(new LinearGradient(0, 0, 0, h, top, bot, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, paint);
        int rgb = shown & 0xFFFFFF;
        int a = theme == 1 ? 0x50 : 0x99;
        paint.setShader(new RadialGradient(w * 0.78f, h * 0.12f, Math.max(w, h) * 0.85f,
                (a << 24) | rgb, rgb, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, paint);
        if (theme == 0) {
            paint.setShader(new RadialGradient(w * 0.1f, h * 0.95f, Math.max(w, h) * 0.6f,
                    0x403A1C8F, 0x003A1C8F, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, paint);
        }
        paint.setShader(null);
    }
}
