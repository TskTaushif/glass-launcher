package com.glass.launcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class Weather {
    public static class Day {
        public String date;
        public double min;
        public double max;
        public int code;
    }

    public static class Result {
        public double temp;
        public int code;
        public List<Day> days = new ArrayList<>();
    }

    public static Result fetch(Prefs p) throws Exception {
        String u = "https://api.open-meteo.com/v1/forecast?latitude=" + p.lat() + "&longitude=" + p.lon()
                + "&current=temperature_2m,weather_code"
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                + "&timezone=auto&forecast_days=5"
                + (p.fahrenheit() ? "&temperature_unit=fahrenheit" : "");
        JSONObject o = new JSONObject(Util.httpGet(u));
        JSONObject cur = o.getJSONObject("current");
        Result r = new Result();
        r.temp = cur.getDouble("temperature_2m");
        r.code = cur.getInt("weather_code");
        JSONObject d = o.getJSONObject("daily");
        JSONArray t = d.getJSONArray("time");
        JSONArray mx = d.getJSONArray("temperature_2m_max");
        JSONArray mn = d.getJSONArray("temperature_2m_min");
        JSONArray wc = d.getJSONArray("weather_code");
        for (int i = 0; i < t.length(); i++) {
            Day day = new Day();
            day.date = t.getString(i);
            day.max = mx.getDouble(i);
            day.min = mn.getDouble(i);
            day.code = wc.getInt(i);
            r.days.add(day);
        }
        return r;
    }

    /** returns {name, lat, lon} */
    public static String[] geocode(String name) throws Exception {
        String u = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&name="
                + URLEncoder.encode(name, "UTF-8");
        JSONObject o = new JSONObject(Util.httpGet(u));
        JSONArray a = o.getJSONArray("results");
        JSONObject r = a.getJSONObject(0);
        String label = r.getString("name");
        if (r.has("admin1")) label = label + ", " + r.getString("admin1");
        return new String[]{label, String.valueOf(r.getDouble("latitude")), String.valueOf(r.getDouble("longitude"))};
    }

    /** Rough location from the internet connection (IP based). */
    public static String[] ipLocate() throws Exception {
        JSONObject o = new JSONObject(Util.httpGet("https://ipwho.is/"));
        if (!o.optBoolean("success", true)) throw new Exception("no location");
        String city = o.optString("city", "My Location");
        return new String[]{city, String.valueOf(o.getDouble("latitude")), String.valueOf(o.getDouble("longitude"))};
    }

    public static String desc(int c) {
        if (c == 0) return "Clear";
        if (c == 1) return "Mostly clear";
        if (c == 2) return "Partly cloudy";
        if (c == 3) return "Overcast";
        if (c == 45 || c == 48) return "Fog";
        if (c >= 51 && c <= 57) return "Drizzle";
        if (c >= 61 && c <= 67) return "Rain";
        if (c >= 71 && c <= 77) return "Snow";
        if (c >= 80 && c <= 82) return "Showers";
        if (c == 85 || c == 86) return "Snow showers";
        if (c >= 95) return "Thunderstorm";
        return "Weather";
    }

    public static String icon(int c) {
        if (c == 0) return "☀️";
        if (c == 1 || c == 2) return "⛅";
        if (c == 3) return "☁️";
        if (c == 45 || c == 48) return "🌫️";
        if ((c >= 51 && c <= 57) || (c >= 80 && c <= 82)) return "🌦️";
        if (c >= 61 && c <= 67) return "🌧️";
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return "❄️";
        if (c >= 95) return "⛈️";
        return "☁️";
    }
}
